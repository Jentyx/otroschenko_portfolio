import java.util.Arrays;

public class Task3 {
    public static void main (String[] args) {
        int[] array = new int[10];

        for (int i = 1; i <= 10; i++) {
            array[i - 1] = i;
        }

        String arrayString = Arrays.toString(array);
        System.out.println("Массив: " + arrayString);

        System.out.print("Элементы массива, кратные трём: ");
        for (int i = 0; i < 10; i++) {
            if (array[i] % 3 == 0) {
                System.out.print(array[i] + " ");
            }
        }
    }
}
