import java.util.Scanner;

public class Task2 {
    public static void main (String[] args) {
        String name = new String("Вячеслав");

        Scanner scan = new Scanner(System.in);
        System.out.print("Введите имя: ");
        String name1 = scan.nextLine();

        if (name.equalsIgnoreCase(name1) == true) {
            System.out.print("Привет, Вячеслав");
        }
        else {
            System.out.print("Нет такого имени");
        }
    }
}
