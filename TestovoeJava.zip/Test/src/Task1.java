import java.util.Scanner;

public class Task1 {
    public static void main (String[] args)
    {
        System.out.print("Введите число: ");
        Scanner scan = new Scanner(System.in);
        int i = scan.nextInt();
        if (i > 7) {
            System.out.print("Привет");
        }
        else {
            System.out.print("Введенное число меньше или равно 7");
        }
    }
}
